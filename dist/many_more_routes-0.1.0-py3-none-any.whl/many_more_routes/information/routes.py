import re
from ..sequence import is_sequencenumber_valid
from getting_and_setting import MiApi


def get_route_seed(ip: str, port: int, usr: str, pwd: str) -> str:
    ''' Fetches the latest route that matches the naming pattern
    ALPHA ALPHA INT INT INT INT such as AA0001 and XY9999.'''

    api = MiApi(
        ip=ip,
        port=port,
        usr=usr,
        pwd=pwd
    )

    mi_routes = api.request('DRS005MI', 'SelRoute', maxrecs=0)
    valid_routes = [
        record['ROUT'] 
        for record
        in mi_routes.records
        if is_sequence_number_valid(record['ROUT'])
    ]        

    return valid_routes


if __name__ == '__main__':
    seed = get_route_seed(
        ip='seep300v.epiroc.group',
        port=20109,
        usr=r'epiroc\nnckten',
        pwd=r'NOps4fut106%'
    )

    print(get_route_seed(seed))